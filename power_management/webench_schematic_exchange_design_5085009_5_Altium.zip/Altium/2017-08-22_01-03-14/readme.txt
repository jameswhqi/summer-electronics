 
 
 
**********************************************************
*************  Important Instructions Follow  ************
**********************************************************
 
All files exported to: Z:\\50\\85\\5085009\\5\Altium\2017-08-22_01-03-14\2017-08-22_01-03-14
 
 
**********************************************************
***************** Schematic Instructions  ****************
**********************************************************

To import your new Schematic into Altium:

1. Unzip the downloaded folder files to a local directory and
Start the Altium program.
2. From the menu select "File"->"Open".
3. Select the file named in the path above ending with ".schdoc"
and "Open" the file.
4. Your Schematic should be viewable within Altium now.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Altium_BrdSch_import.html



**********************************************************
*******************  PCB Instructions  *******************
**********************************************************


To import your new BOARD into Altium:

1. Unzip the downloaded folder files to a local directory
	and Start the Altium program.
2. From the menu select "File"->"Open".
3. Select the file named in the path above ending with ".pcbdoc"
and "Open" the file.
4. Planes will need to be repoured to update the Copper Pour Polygons
	a. Once your board is loaded, select the Tools menu from the
	   top Menu Bar
	b. Scroll to the Polygon Pours item on the Tools Menu.
	c. The Polygon Pours item should expand to show more options
	d. Select Repour All Polygons, this will repour all of the
	   polygons.
5. Your board should be viewable within Altium now.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Altium_BrdSch_import.html

**********************************************************
*******************  LIB Instructions  *******************
**********************************************************

To import your new LIBRARY PARTS into Altium follow these steps:

1. After running the Ultra Librarian export for the first time,
you will need to copy the following files into an area where
they can be accessed for all future translations.  They are script
files that Altium will need to be able to find.
	a. UL_Form.dfm
	b. UL_Form.pas
	c. UL_Import.pas
	d. UL_Import.prjScr
2. The above script file will need to be run from within Altium.
This can be done by going to File, Open and selecting the
UL_Import.PrjScr file stored above.
3. Select the "DXP" dropdown menu in the top-left corner runfrom
the drop down menu and select "Run Script". Select "UL_Form.pas"
and click "OK"
4. When the script is run, it will ask you for the file name of the
Ultra Librarian file to run. Click "File...", select the latest file
produced with a date code (for instance 2010-02-17_23-12-34.txt), and
click "Start Import".
5. The script will open a new Integraged Library project and import
the Ultra Librarian data into it.  When complete a message box
will pop up saying that import is done.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Altium_import.html

For a video tutorial, please visit:
http://youtu.be/pih50yx9HYU

**********************************************************
**********************************************************
**********************************************************
 
 
Padstack "RX78p74Y236p22D0T" renamed to "RX78p74Y236p22D0"
Symbol "WB_STARTUP_VOLTAGE_SOURCE" renamed to "WB_STARTUP_VOLTA"
Symbol "WB_SOURCE_RESISTOR" renamed to "WB_SOURCE_RESIST"
Symbol "WB_PRIM_STARTUP_VOLTAGE_SOURCE" renamed to "WB_PRIM_STARTUP_"
Symbol "WB_PWL_CURRENT_LOAD" renamed to "WB_PWL_CURRENT_L"
Symbol "WB_DIODE_SCHOTTKY" renamed to "WB_DIODE_SCHOTTK"
Symbol "WB_PRIM_AC_VOLTAGE_SOURCE" renamed to "WB_PRIM_AC_VOLTA"
Symbol "WB_PRIMITIVE_CAPACITOR" renamed to "WB_PRIMITIVE_CAP"
Symbol "WB_PRIMITIVE_INDUCTOR" renamed to "WB_PRIMITIVE_IND"
Symbol "WB_PRIM_PULSE_VOLTAGE_SOURCE" renamed to "WB_PRIM_PULSE_VO"
Symbol "WB_PWL_VOLTAGE_SOURCE" renamed to "WB_PWL_VOLTAGE_S"
Symbol "WB_PRIM_PWL_VOLTAGE_SOURCE" renamed to "WB_PRIM_PWL_VOLT"
Symbol "WB_PRIMITIVE_BATTERY" renamed to "WB_PRIMITIVE_BAT"
Component "GRM155R61A104KA01D" renamed to "GRM155R61A104KA0"
Component "CL21C511JBANNNC" renamed to "CL21C511JBANNNC"
Component "C0805C180K5GACTU" renamed to "C0805C180K5GACTU"
Component "GRM188R61A225KE34D" renamed to "GRM188R61A225KE3"
Component "C2012X5R1A476M125AC" renamed to "C2012X5R1A476M12"
Component "CC0805KRX7R9BB682" renamed to "CC0805KRX7R9BB68"
Component "SS24FL" renamed to "SS24FL"
Component "WB_GND" renamed to "WB_GND"
Component "SRN6045-3R3Y" renamed to "SRN6045-3R3Y"
Component "CRCW040256K2FKED" renamed to "CRCW040256K2FKED"
Component "CRCW040229K4FKED" renamed to "CRCW040229K4FKED"
Component "CRCW0402107KFKED" renamed to "CRCW0402107KFKED"
Component "CRCW040210K0FKED" renamed to "CRCW040210K0FKED"
Component "CRCW040253K6FKED" renamed to "CRCW040253K6FKED"
Component "CRCW040284K5FKED" renamed to "CRCW040284K5FKED"
Component "TPS54160DGQR" renamed to "TPS54160DGQR"
Component "WB_BATTERY" renamed to "WB_BATTERY"
Component "WB_CURRENT_LOAD" renamed to "WB_CURRENT_LOAD"
The Symbol WB_CONTINUATION was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CONTINUATION was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CONTINUATION was missing a Value attribute, a value was created for the symbol.
The Symbol WB_BLOCK_IO was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_BLOCK_IO was missing a Type attribute, a type was created for the symbol.
The Symbol WB_BLOCK_IO was missing a Value attribute, a value was created for the symbol.
The Symbol WB_STARTUP_VOLTA was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_STARTUP_VOLTA was missing a Type attribute, a type was created for the symbol.
The Symbol WB_STARTUP_VOLTA was missing a Value attribute, a value was created for the symbol.
The Symbol WB_SOURCE_RESIST was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_SOURCE_RESIST was missing a Type attribute, a type was created for the symbol.
The Symbol WB_SOURCE_RESIST was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIM_STARTUP_ was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIM_STARTUP_ was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIM_STARTUP_ was missing a Value attribute, a value was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PWL_CURRENT_L was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PWL_CURRENT_L was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PWL_CURRENT_L was missing a Value attribute, a value was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIM_AC_VOLTA was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIM_AC_VOLTA was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIM_AC_VOLTA was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIMITIVE_CAP was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIMITIVE_CAP was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIMITIVE_CAP was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIMITIVE_IND was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIMITIVE_IND was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIMITIVE_IND was missing a Value attribute, a value was created for the symbol.
The Symbol WB_ALCOR_VSYNC was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_ALCOR_VSYNC was missing a Type attribute, a type was created for the symbol.
The Symbol WB_ALCOR_VSYNC was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIM_PULSE_VO was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIM_PULSE_VO was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIM_PULSE_VO was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PWL_VOLTAGE_S was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PWL_VOLTAGE_S was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PWL_VOLTAGE_S was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIM_PWL_VOLT was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIM_PWL_VOLT was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIM_PWL_VOLT was missing a Value attribute, a value was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a Type attribute, a type was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIMITIVE_BAT was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIMITIVE_BAT was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIMITIVE_BAT was missing a Value attribute, a value was created for the symbol.


Ultra Librarian Gold 8.1.204 Process Report


Message - Component "GRM155R61A104KA0" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R61A104KA0" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R61A104KA0" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R61A104KA0" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C511JBANNNC" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C511JBANNNC" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C511JBANNNC" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C511JBANNNC" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C511JBANNNC" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0805C180K5GACTU" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0805C180K5GACTU" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0805C180K5GACTU" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0805C180K5GACTU" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0805C180K5GACTU" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM188R61A225KE3" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM188R61A225KE3" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM188R61A225KE3" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM188R61A225KE3" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1A476M12" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1A476M12" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1A476M12" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1A476M12" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1A476M12" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CC0805KRX7R9BB68" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CC0805KRX7R9BB68" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CC0805KRX7R9BB68" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CC0805KRX7R9BB68" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SS24FL" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SS24FL" attribute "Io" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SS24FL" attribute "VRRM" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SS24FL" attribute "VFatIo" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SRN6045-3R3Y" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SRN6045-3R3Y" attribute "L" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SRN6045-3R3Y" attribute "DCR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SRN6045-3R3Y" attribute "IDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040256K2FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040256K2FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040256K2FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040229K4FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040229K4FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040229K4FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW0402107KFKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW0402107KFKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW0402107KFKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040210K0FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040210K0FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040210K0FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040253K6FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040253K6FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040253K6FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040284K5FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040284K5FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040284K5FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS54160DGQR" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS54160DGQR" attribute "Frequency" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS54160DGQR" attribute "Imax" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS54160DGQR" attribute "Package" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS54160DGQR" attribute "Mktg_Package" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS54160DGQR" attribute "NSID" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.

TextStyle count:  24
Padstack count:   7
Pattern count:    6
Symbol count:     25
Component count:  18

Export

Footprint "0402" has no layer data mapped and will be skipped.
Component "GRM155R61A104KA0" requires footprint "0402" and will be skipped.
Component "CRCW040256K2FKED" requires footprint "0402" and will be skipped.
Component "CRCW040229K4FKED" requires footprint "0402" and will be skipped.
Component "CRCW0402107KFKED" requires footprint "0402" and will be skipped.
Component "CRCW040210K0FKED" requires footprint "0402" and will be skipped.
Component "CRCW040253K6FKED" requires footprint "0402" and will be skipped.
Component "CRCW040284K5FKED" requires footprint "0402" and will be skipped.
Footprint "0805" has no layer data mapped and will be skipped.
Component "CL21C511JBANNNC" requires footprint "0805" and will be skipped.
Component "C0805C180K5GACTU" requires footprint "0805" and will be skipped.
Component "C2012X5R1A476M12" requires footprint "0805" and will be skipped.
Component "CC0805KRX7R9BB68" requires footprint "0805" and will be skipped.
Footprint "0603" has no layer data mapped and will be skipped.
Component "GRM188R61A225KE3" requires footprint "0603" and will be skipped.
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "Io" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "VRRM" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "VFatIo" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "TOL" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "VAL" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "DEV" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "PN" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "L" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "DCR" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "IDC" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "PN" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "DEV" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "VAL" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "TOL" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "RefDes2" references missing text style ""
Warning: Symbol "WB_TPS54160" attribute "PN" references missing text style ""
Warning: Symbol "WB_TPS54160" attribute "DEV" references missing text style ""
Warning: Symbol "WB_TPS54160" attribute "VAL" references missing text style ""
Warning: Symbol "WB_TPS54160" attribute "TOL" references missing text style ""
Warning: Symbol "WB_TPS54160" attribute "RefDes2" references missing text style ""
